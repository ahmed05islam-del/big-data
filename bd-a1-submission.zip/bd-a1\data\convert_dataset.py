
import csv

with open("data/SMSSpamCollection", "r", encoding="utf-8") as source:
    with open("data/dataset.csv", "w", newline="", encoding="utf-8") as target:
        writer = csv.writer(target)
        writer.writerow(["label", "text"])

        for line in source:
            label, text = line.rstrip("\r\n").split("\t", 1)
            writer.writerow([label, text])

print("Dataset converted successfully!")
