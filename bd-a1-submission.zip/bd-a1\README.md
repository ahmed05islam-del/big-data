
# CSCI461 - SMS Spam Detection

## Dataset
SMS Spam Collection - UCI Repository
https://archive.ics.uci.edu/dataset/228/sms+spam+collection

## Project Description
SMS Spam and Ham Classification using
Text Analysis and Machine Learning.

## Technologies
Python, Pandas, Scikit-learn,
Matplotlib, Seaborn, Docker, JupyterLab

## Docker Build
docker build -t csci461-sms:v1 .

## Docker Run (PowerShell)
docker run -d --name sms-analysis -p 8888:8888 -v "${PWD}\output:/home/jovyan/bd-a1/output" csci461-sms:v1

## Access JupyterLab
docker logs sms-analysis

Open the localhost:8888 URL with its token.

## Docker Concepts
Image: A packaged environment with dependencies.
Container: A running instance of an image.
Port 8888:8888: Host port mapped to container port.
Bind mount: Makes output files persistent on Windows.

## Machine Learning
- TF-IDF
- Multinomial Naive Bayes
- K-Means Clustering

## Outputs
- cleaned_data.csv
- model_metrics.txt
- cluster_summary.txt
- figures/

## Reproducibility
Build the Docker image and run the container.
Open notebook/analysis.ipynb in JupyterLab.
Select Kernel > Restart Kernel and Run All Cells.

## Docker Hub
Repository: YOUR_USERNAME/csci461-sms
Tag: v1

docker login
docker tag csci461-sms:v1 YOUR_USERNAME/csci461-sms:v1
docker push YOUR_USERNAME/csci461-sms:v1

Another team member should pull the image
and verify that it runs successfully.
